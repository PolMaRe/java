package com.example.persona.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.persona.modelo.Factura;

public interface FacturaRepository extends JpaRepository<Factura, Long> {

}
