package com.example.persona.rest;

public class CategoriaREST {

}
