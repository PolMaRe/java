package com.example.persona.rest;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.persona.service.DetalleFacturaService;
import com.example.persona.modelo.DetalleFactura;

@RestController
@RequestMapping("/detallefactura/")
public class DetalleFacturaREST {

	@Autowired
	private DetalleFacturaService detallefacturaService;

	@GetMapping
	private ResponseEntity<List<DetalleFactura>> getAllPPersonas() {
		return ResponseEntity.ok(detallefacturaService.findAll());
	}

	@PostMapping
	private ResponseEntity<DetalleFactura> savePersona(@RequestBody DetalleFactura persona) {
		try {
			DetalleFactura detallefacturaGuardada = detallefacturaService.save(persona);
			return ResponseEntity.created(new URI("/detallefactura/" + detallefacturaGuardada.getProducto())).body(detallefacturaGuardada);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
	}
	
	/*
	@DeleteMapping (value = "delete/{id}")
	private ResponseEntity<boolean> deletePersona(@PathVariable ("id") Long id){
		personaservice
	}
	*/
}
